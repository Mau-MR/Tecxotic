#include "Arduino.h"
#include "ESCController.h"
#include "Servo.h"

ESCController::ESCController(byte _esc, int _led, int _button, byte _potentiometer)
{
    esc_pin = _esc;
    led_pin = _led;
    button_pin = _button;
    potentiometer_pin = _potentiometer;

    pinMode(led_pin, OUTPUT);
    pinMode(button_pin, INPUT_PULLUP);
    esc_thruster.attach(esc_pin);
    esc_thruster.writeMicroseconds(1500); // send "stop" signal to ESC. Also necessary to arm the ESC.
    delay(400); // delay to allow the ESC to recognize the stopped signal.
}
int ESCController::getPotentiometerValue()
{
    int potVal = analogRead(potentiometer_pin); // read input from potentiometer.
    int pwmVal = map(potVal,0, 1023, 1100, 1900); // maps potentiometer values to PWM value.
    return pwmVal;
}
void ESCController::run()
{
    if(action_on) {
        pwm_val = getPotentiometerValue();
        digitalWrite(led_pin, HIGH);
        Serial.println(pwm_val);
        esc_thruster.writeMicroseconds(pwm_val); // Send signal to ESC.
    }
    else{
        digitalWrite(led_pin, LOW);
        esc_thruster.writeMicroseconds(1500); // Send signal to ESC.
    }

    if (digitalRead(button_pin) == false) {
        if (!action_off) {
            action_on = !action_on;
            action_off = true;
        }
    }
    else {
        action_off = false;
    }


}
























