#ifndef ESCController_h
#define ESCController_h
#include "Arduino.h"
#include "Servo.h"

class ESCController
{
    public:
        ESCController();
        ESCController(byte esc_pin, int led_pin, int button, byte potentiometer);
        void run();
    private:
        byte esc_pin; // 9  ex
        int led_pin; //13   ex 
        int button_pin; //2  ex 
        byte potentiometer_pin; // A0 ex
        bool action_on = false;
        bool action_off = false;
        int pwm_val;
        Servo esc_thruster;
        int getPotentiometerValue();

};

#endif